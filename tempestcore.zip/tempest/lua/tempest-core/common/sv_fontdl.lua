
-- ----------- --
-- Tempest Hud --
-- ----------- --
-- 
-- Written by Melon (https://peepee.us/)
-- 
-- Purpose: Sends the font to clients

resource.AddSingleFile("resource/fonts/poppins_tempest.ttf")
resource.AddWorkshop("2631771632")