
Tempest.F4 = Tempest.F4 or {}
Tempest.F4.Config = Tempest.F4.Config or {}

Tempest.F4.Config.Links = {
    ["Discord"] = {"https://discord.gg/uCCfDHgbDy", "etvpe3c"},
    ["Workshop"] = {"https://steamcommunity.com/sharedfiles/filedetails/?id=2589707982", "etvpe3c"},
}